
# V6 Lovent — Sobre + tarjeta estilo LoventInvita (sin PDFs)

- Sobre champagne/rose-gold que se abre y se desvanece.
- Tras abrir, se muestran secciones tipo Lovent: portada, detalles, dress code, mapa y CTA.
- Tipografías Bodoni Moda (títulos) y Catamaran (texto).

## Uso
1. Copia esta carpeta en la raíz de tu proyecto Next.js.
2. `npm run dev`
3. Abre `http://localhost:3000/invitacion-v6`

Personaliza colores en `styles/globals.css` y textos/horarios en `pages/invitacion-v6.jsx`.
