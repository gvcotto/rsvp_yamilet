export { default } from '@/components/FirstPageText';
