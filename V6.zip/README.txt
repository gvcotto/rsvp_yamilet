RSVP V5 (estilo Loventinvita)

Copia estos archivos dentro de tu proyecto Next.js respetando rutas.
Requisitos:
- npm i qrcode.react
- Si usas Tailwind, no hace falta configurar nada extra.
- Puedes poner tu música en /public/music/song.mp3

Abre: /invitacion?p=TOKEN&n=Nombre
